#!/bin/bash
#SBATCH --job-name=covu_nni
#SBATCH --output=logs/%x_%A_%a.out
#SBATCH --error=logs/%x_%A_%a.err
#SBATCH --partition=V100
#SBATCH --gres=gpu:1
#SBATCH --cpus-per-task=8
#SBATCH --mem=32G
#SBATCH --time=36:00:00
#SBATCH --array=0-900  # Número total de combinaciones - 1 (en este caso  combinaciones)

# -------------------------------
# Preparar combinaciones
# -------------------------------
SEEDS=($(seq 0 99))
PERCENTAGES=(0.50 0.60 0.70 0.80 0.90 0.995)

COMBINATIONS=()
for seed in "${SEEDS[@]}"; do
    for percentage in "${PERCENTAGES[@]}"; do
        COMBINATIONS+=("$seed $percentage")
    done
done

# Obtener parámetros para esta tarea
read SEED PERCENTAGE <<< "${COMBINATIONS[$SLURM_ARRAY_TASK_ID]}"

echo "Running task $SLURM_ARRAY_TASK_ID with seed=$SEED and percentage=$PERCENTAGE"

# -------------------------------
# Activar entorno
# -------------------------------
source /home/ids/jpabon/miniconda3/etc/profile.d/conda.sh
conda activate smooth_gsp

# -------------------------------
# Ejecutar script
# -------------------------------
python scripts/main_train.py \
    --dataset covid_19_new_cases_USA \
    --knn 10 \
    --epochs 20000 \
    --method nni \
    --lr 0.1 \
    --percentage "$PERCENTAGE" \
    --seed "$SEED" \
    --type_sampler 'random'

echo "Finished task $SLURM_ARRAY_TASK_ID"
#python scripts/main_train.py --dataset PM2_5_concentration --knn 10 --epochs 20000 --method Sobolev --lr 0.1 --percentage 0.1 --coefficient_mse 0.5 --coefficient_sob 1e-05 --epsilon 0.2 --beta 1.0 --seed 42 --type_sampler 'random'
